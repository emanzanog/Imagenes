
$(
	$.ajax({
		url :"./json/imgs"+nombreRandom(4)+".json",
		dataType: "JSON",
		type:"GET"
		}
	).done(data=>{
		//var datos = JSON.parse(data);
		console.log(data);	

		var imagenes = [];
		for (var i in data) {
			var imgUrl = data[i].imgUrl;
			var link = data[i].link;
			console.log(imgUrl, link);
			var enlace = $("<a>");
			var imagen = $("<img/>");
			enlace.attr("href",link);
			imagen.attr("src",imgUrl);
			enlace.append(imagen);
			$(".grupoImg").each((i,e)=>{
				$(e).append(enlace);
			});
			imagenes.push(enlace);
			//console.log($(this));

		}
		
		
	})
);

function nombreRandom(n){
	return Math.floor(Math.random()*n)+1;
}