
$( //El número dentro de nombreRandom() corresponde al número de archivos json que tengas.
	$.ajax({
		url :"./json/imgs"+nombreRandom(4)+".json",
		dataType: "JSON",
		type:"GET"
		}
	).done(data=>{
		//creo un array donde guardaremos las imágenes con el enlace
		var imagenes = [];
		//decorro los datos del json
		for (var i in data) {
			var imgUrl = data[i].imgUrl;
			var link = data[i].link;
			//creo un enlace ..
			var enlace = $("<a>");
			//y una imagen
			var imagen = $("<img/>");
			//asigno las url a sus respectivas etiquetas
			enlace.attr("href",link);
			imagen.attr("src",imgUrl);
			//cambiando ancho y alto de la imágen (pixels)
			imagen.width(100);
			imagen.height(100);
			//meto la imagen dentro del enlace
			enlace.append(imagen);
			//guardo los enlaces con imagenes en el array
			imagenes.push(enlace);
			//console.log($(this));
		}
		var $grupoImg = $(".grupoImg");
		var v = 0;
		//aquí muestro las imágenes en cada div
		for(v=0; v< imagenes.length; v++){
			console.log($(this));
			var actual = imagenes[v];
			$grupoImg.append(actual);
		}
	})
);

function nombreRandom(n){
	return Math.floor(Math.random()*n)+1;
}